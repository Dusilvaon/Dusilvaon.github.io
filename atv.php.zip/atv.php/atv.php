<!DOCTYPE html>
<html lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>atividade</title>
    <link rel="stylesheet" href="bootstrap.css"> 
    <script src="atv.js"></script>
</head>
<body>
<div class="container">
        <div class= col>
            <h1>Cadastro CEP</h1>
            <hr>
            <form action="salvar.php" method="POST">
                
                <div>
                    <label for="cep" class="form-label">CEP</label>
                    <input type="text" class= "form-control" id= "cep" name="cep" placeholder="CEP" onblur="salvarCEP()"> 
                </div>
                <div>
                    <label for="logradouro"class= "form-label">logradouro</label>
                    <input type="text" class="form-control" id= "logradouro" name="logradouro" placeholder="logradouro">
                </div>
                <div>
                    <label for="logradouro"class= "form-label">complemento</label>
                    <input type="text" class="form-control" id= "complemento" name="complemento" placeholder="complemento">
                </div>
                <div>
                    <label for="logradouro"class= "form-label">bairro</label>
                    <input type="text" class="form-control" id= "bairro" name="bairro" placeholder="bairro">
                </div>
                <div>
                    <label for="logradouro"class= "form-label">localidade</label>
                    <input type="text" class="form-control" id= "localidade" name="localidade" placeholder="localidade">
                </div>
                <div>
                    <label for="logradouro"class= "form-label">uf</label>
                    <input type="text" class="form-control" id= "uf" name="uf" placeholder="uf">
                </div>
                <div>
                    <label for="logradouro"class= "form-label">ibge</label>
                    <input type="text" class="form-control" id= "ibge" name="ibge" placeholder="ibge">
                </div>
                <div>
                    <label for="logadouro"class= "form-label">ddd</label>
                    <input type="text" class="form-control" id= "ddd" name="ddd" placeholder="ddd">
                </div>
                
 </form>
    </div>
    
</body>
</html>